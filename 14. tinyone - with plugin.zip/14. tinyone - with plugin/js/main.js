(function ($){
	'use strict'

	//Code starts

	/*
	$('.menu-icon i').on('click',function(){
		$('.slide-menu').animate({
			'left':0
		});
	});
	$('.menu-close i').on('click',function(){
		$('.slide-menu').animate({
			'left': '-250px'
		});
	});
	*/

	$('.menu-icon i').on('click', function() {
    $('.slide-menu').animate({
        'left': 0
    });
});
$('.menu-close i').on('click', function() {
    $('.slide-menu').animate({
        'left': '-250px'
    });
});

	//owl carousel setup
		$('.owl-carousel').owlCarousel({
	    loop:true,
	    margin:10,
	    autoplay: true,
	    autoplayTimeout: 1000,
	    navText: ['P','N'],
	    nav:true,
	    responsive:{
	        0:{
	            items:1
	        },
	        600:{
	            items:3
	        },
	        1000:{
	            items:5
	        }
	    }
	})
		//isotop plugin for product categorization
		// filter items on button click
			$('.filter-button-group').on( 'click', 'button', function() {
			  var filterValue = $(this).attr('data-filter');
			  $grid.isotope({ filter: filterValue });
			});

			var $grid=$('.grid').isotope({
		  // set itemSelector so .grid-sizer is not used in layout
		  itemSelector: '.grid-item',
		  percentPosition: true,
		  masonry: {
		    // use element for option
		    columnWidth: '.grid-item'
		  }
		})


		$('.product-button button').on('click',function(){
			$('.product-button button').removeClass('current');
			$(this).addClass('current');
		})

	

}) (jQuery);